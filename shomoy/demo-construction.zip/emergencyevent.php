<div class="home-intro bg-primary" id="home-intro">
					<div class="container">

						<div class="row align-items-center">
							<div class="col-lg-8">
								<p>
									Running Event  
                                                     
									<span> <span class="highlighted-word">IDEA Chellenges</span></span>
								</p>
							</div>
							<div class="col-lg-4">
								<div class="get-started text-start text-lg-end">
									<a href="#" class="btn btn-dark btn-lg text-3 font-weight-semibold px-4 py-3">Regestation Now</a>
									<div class="learn-more">or <a href="index.html">learn more.</a></div>
								</div>
							</div>
						</div>

					</div>
				</div>