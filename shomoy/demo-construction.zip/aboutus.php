<div id="aboutus" class="container py-5 mt-3 mb-5">
					<div class="row row-gutter-sm align-items-center justify-content-center">
						<div class="col-6 col-md-4 col-lg-3 align-self-start">
							<img src="img/demos/restaurant/generic/generic-1-big.jpg" class="img-fluid box-shadow-4 rounded-0" alt="Restaurant inside showcase 1" />
						</div>
						<div class="col-6 col-md-4 col-lg-3 align-self-start mb-5 mb-lg-0">
							<img src="img/demos/restaurant/generic/generic-2-small.jpg" class="img-fluid box-shadow-4 rounded-0 mb-3 mb-sm-4" alt="Restaurant inside showcase 2" />
							<img src="img/demos/restaurant/generic/generic-3-small.jpg" class="img-fluid box-shadow-4 rounded-0" alt="Restaurant inside showcase 3" />
						</div>
						<div class="col-lg-6 ps-lg-3 ps-xl-5">
							<h2 class="text-color-primary positive-ls-3 text-4 line-height-3 mb-2 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="300">ABOUT US</h2>
							<h3 class="text-color-dark text-transform-none text-9 line-height-3 font-weight-medium mb-4 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="500">Using the very <span class="highlight highlight-primary highlight-bg-opacity highlight-animated" data-appear-animation="highlight-animated-start" data-appear-animation-delay="1200" data-plugin-options="{'flagClassOnly': true}">best ingredients</span> we have access to.</h3>
							<p class="text-3-5 pb-2 mb-4 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="700">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque molestie vel turpis a sodales. In hac habitasse platea dictumst. Nulla sollicitudin dui vitae leo aliquet. </p>
							<a href="#" class="btn btn-dark font-weight-medium text-3 btn-px-4 py-3 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="900">More About Us</a>
						</div>
					</div>
				</div>